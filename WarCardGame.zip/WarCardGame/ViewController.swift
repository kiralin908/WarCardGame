//
//  ViewController.swift
//  WarCardGame
//
//  Created by 林郁琦 on 2024/2/29.
//

import UIKit
import Foundation
struct Card {
    var suit: String
    var rank: String
}

class ViewController: UIViewController {
    
    
    @IBOutlet weak var bankerCard: UIImageView!
    @IBOutlet weak var playerCard: UIImageView!
    @IBOutlet weak var resultLabel: UILabel!
    
    
    var cards = [Card]()
    func createCard() {
        let suits = ["C", "D", "H", "S"]
        let ranks = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
        for suit in suits {
            for rank in ranks {
                let card = Card(suit: suit, rank: rank)
                cards.append(card)
                
            }
        }
    
    }
 
   
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createCard()
        
     
        
        
        
    }
    
    func cardSuitsNumber(suit: String) -> Int {
        var number = 0
        switch suit {
        case "C":
            number = 1
        case "D":
            number = 2
        case "H":
            number = 3
        default:
            number = 4
            }
        return number
    }
        
    func cardRankNumber(rank: String) -> Int {
        var number = 0
        switch rank {
        case "A":
            number = 1
        case "J":
            number = 11
        case "Q":
            number = 12
        case "K":
            number = 13
        default:
            number = Int(rank)!
        }
        return number
    }
    
    @IBAction func playButton(_ sender: Any) {
        cards.shuffle()
        
        
        
        
        
        
       
        
        
        
        
        
        
      
        
      
        
        
        
        
        
        
        
        
    }
}

